# NovaForge real-build status

## Completed in source

- Android compile/target SDK is 36.
- CI uses a networked runner and installs dependencies before typecheck/test/build.
- Docker build no longer assumes a committed npm lockfile and does not copy a nonexistent public directory.
- Cloud Run deploys the web service and a persistent worker service from the same immutable image.
- AI providers are explicit adapters; missing credentials cause a real job failure instead of a fake artifact URL.
- Release checks and security source checks remain mandatory.

## External gates

These cannot be truthfully completed inside a source archive without the corresponding account credentials: Android release signing/Play publishing, Apple signing/App Store Connect publishing, GCP project/Workload Identity, database secrets, and AI provider keys.

## Verification rule

A green GitHub Actions run is the authoritative evidence for dependency installation, TypeScript, tests, Next.js production build, Android build, container build and deployment.

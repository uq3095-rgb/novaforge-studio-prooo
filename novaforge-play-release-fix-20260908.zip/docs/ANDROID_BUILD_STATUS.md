# Android build status

The Android project targets compileSdk 36 and targetSdk 36. CI provisions Java 21, Android SDK platform 36/build-tools 36.0.0, and Gradle 8.13 before running `gradle assembleDebug`.

For Google Play, the release gate must produce a signed AAB. Signing material must be supplied through GitHub/GCP secret infrastructure; it is never committed.

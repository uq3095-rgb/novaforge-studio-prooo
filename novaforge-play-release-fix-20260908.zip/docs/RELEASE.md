# Release gate

1. Networked dependency installation.
2. Prisma generation.
3. TypeScript typecheck.
4. Unit tests.
5. Release/source/security checks.
6. npm audit.
7. Next.js production build.
8. Android API 36 build.
9. Container build.
10. Cloud Run web + worker deployment on version tags.
11. Deployment health verification.
12. Store-specific signed release and review gates.

No stage may report SUCCESS merely because an expected artifact filename exists.

# Android / Google Play release package

The web application is the primary product. Android publication requires a signed native wrapper
(for example Capacitor) or a dedicated native client.

## Release gate
1. Set the final Android applicationId/package name.
2. Generate the Android project with the chosen wrapper.
3. Configure the production HTTPS origin.
4. Set target SDK to Android 16 / API 36 or higher for new apps and updates in 2026.
5. Create a release keystore or use Google Play App Signing.
6. Build a signed Android App Bundle (`.aab`).
7. Run internal testing first, then closed/open testing as appropriate.
8. Complete store listing, Data Safety, privacy policy, content declarations and review credentials.
9. Upload the AAB and promote the tested release to production.

## CI secret policy
Never commit:
- keystores
- passwords
- Play service-account JSON
- signing keys
- API tokens

Use GitHub Actions OIDC / Google Cloud Workload Identity where possible and GitHub encrypted secrets
for Android publishing credentials.

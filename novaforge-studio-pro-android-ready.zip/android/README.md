# NovaForge Studio Pro — Android

This is the real Android WebView client for NovaForge Studio Pro. It targets Android API 36 and is built by GitHub Actions with Gradle 8.13.

Set the GitHub Actions secret `NOVAFORGE_URL` to the HTTPS production URL of the deployed NovaForge web application. The CI job then injects that URL into the APK at build time.

The generated debug APK is uploaded as the `novaforge-android-debug-apk` Actions artifact. Production distribution must use a signed AAB and Google Play App Signing.

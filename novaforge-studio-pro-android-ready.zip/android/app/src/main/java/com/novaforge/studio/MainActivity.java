package com.novaforge.studio;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String url = BuildConfig.NOVAFORGE_URL;
        if (url == null || url.trim().isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("NovaForge Studio Pro\\n\\nSet NOVAFORGE_URL in the Android CI build to connect this app to the deployed NovaForge web service.");
            tv.setTextColor(Color.WHITE); tv.setTextSize(18); tv.setPadding(48,48,48,48); tv.setBackgroundColor(Color.rgb(16,16,20));
            setContentView(tv); return;
        }
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
        });
        setContentView(webView, new ViewGroup.LayoutParams(-1,-1));
        webView.loadUrl(url);
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}

# Security baseline

- Hash API keys; never store raw keys.
- Enforce tenant/project ownership on every query and mutation.
- Use RBAC for admin operations.
- Keep provider secrets in Secret Manager.
- Redact secrets/tokens from logs and agent context.
- Validate uploads by MIME, extension, size and content.
- Block SSRF in URL ingestion.
- Do not execute generated code in the web process.
- Add audit events for auth, billing, project, deployment and secret operations.
- Use least-privilege service accounts.
- Pin CI actions and dependencies where practical.
- Run dependency and container vulnerability scans.
- Require signed Android releases.

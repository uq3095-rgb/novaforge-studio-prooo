# NovaForge AI Software Factory Pipeline

## Production pipeline

Requirement
→ Planner
→ Architect
→ Coder
→ Dependency/Build
→ Isolated Sandbox
→ Test Agent
→ Security Agent
→ Reviewer
→ Fix Loop
→ Artifact
→ Git branch/commit
→ Preview deployment
→ Human/Policy gate
→ Production deployment

## Agent contracts

Each agent receives a typed job envelope:

- `jobId`
- `projectId`
- `actorId`
- `objective`
- `constraints`
- `artifacts`
- `budget`
- `modelPolicy`
- `securityPolicy`

Each agent must return:
- status
- structured result
- changed files
- test evidence
- warnings
- token/cost metadata

## Isolation

Generated code must never execute in the Next.js request process.
Use short-lived isolated workers/containers with:
- no host filesystem access
- restricted network egress
- CPU/memory/time limits
- read-only base image
- non-root user
- explicit artifact output directory

## Provider abstraction

Use a provider-neutral gateway:

`AIProvider.generate(request) -> ProviderResult`

Keep model routing, retries, budgets, telemetry and safety policy above individual SDKs.

## Async jobs

App generation, builds, tests and media generation should be queued.
The web request creates a job and returns a job id; workers process it asynchronously.

## Git-native workflow

1. Create project branch.
2. Generate changes.
3. Run typecheck/tests/security checks.
4. Commit with machine-readable message.
5. Open PR or preview deployment.
6. Require policy approval for production.
7. Deploy immutable image tagged with the release version.

## Failure policy

No green status may be emitted when a required gate was skipped.
No deployment step should print success unless the deployment command actually exits successfully.


## Implemented control-plane API

- `POST /api/v1/projects` — create a tenant-owned project.
- `GET /api/v1/projects` — list projects owned by the API-key user.
- `POST /api/v1/ai/generate` — enqueue a text/app/bot job and return `202`.
- `GET /api/v1/jobs/:id` — inspect a job owned by the caller.
- `POST /api/v1/jobs/:id` — synchronous dev execution of a queued job; production should use the worker.
- `POST /api/v1/keys` — one-time bootstrap key issuance protected by `ADMIN_BOOTSTRAP_TOKEN`.

The production worker claims jobs atomically (`QUEUED → RUNNING`) so multiple worker instances do not intentionally process the same job.

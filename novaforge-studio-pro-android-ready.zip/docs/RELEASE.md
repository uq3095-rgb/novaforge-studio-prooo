# Release procedure

## 1. Version
Update `package.json` and create a Git tag:

`vX.Y.Z`

## 2. CI gates
CI must pass:
- typecheck
- unit tests
- release check
- dependency audit
- production build

## 3. Container
Build and push an immutable image tagged with the Git version.

## 4. Database
Apply migrations before or as part of the controlled deployment window.

## 5. Cloud Run
Deploy the exact immutable image. Keep unauthenticated access disabled unless an API gateway/auth layer
explicitly requires public ingress.

## 6. Smoke test
Verify:
- `/api/health`
- authentication
- database connectivity
- one representative AI job
- logs/metrics
- rollback path

## 7. Android
Produce and test an AAB separately. Do not claim Play production readiness until the signed AAB has passed
internal testing and the Play Console release gates.

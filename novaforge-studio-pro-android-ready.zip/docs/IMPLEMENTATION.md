# NovaForge implementation contract

## Runtime
- Next.js 16.3.x App Router control plane.
- PostgreSQL + Prisma durable state.
- Hashed machine API keys for API v1.
- Provider-neutral gateway with OpenAI Responses, Anthropic Messages and Gemini generateContent adapters.
- Queue-first jobs: HTTP creates `QUEUED`; a worker claims and executes jobs.

## Non-negotiable rules
1. Never claim a build, test or deployment succeeded without command evidence.
2. Never execute generated code in the web request process.
3. Never persist plaintext API keys after issuance.
4. Scope every tenant query by owner/user.
5. Surface provider failures; never fabricate success.
6. Production deployment is a separately gated operation.

## Current implementation
Text/app/bot jobs are implemented through the gateway. Image/video are intentionally explicit extension points because their provider APIs, quotas and artifact lifecycle differ materially from text. The platform should return an explicit configuration/unsupported error rather than inventing media output.

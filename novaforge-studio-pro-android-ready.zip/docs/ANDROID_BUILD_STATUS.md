# Android build status

- Android wrapper source: created.
- Target SDK: 36.
- Application ID: com.novaforge.studio.
- CI build: configured with Gradle 8.13 and Android SDK 36.
- APK artifact: produced by GitHub Actions after a successful run.
- Production URL: supplied through `NOVAFORGE_URL` GitHub Actions secret.
- Signing: intentionally externalized; no keystore or signing secret is committed.

Local environment note: this development container does not have the Android SDK/Gradle toolchain or working DNS access, so a local APK build is not represented as successful. The authoritative build is the networked GitHub Actions runner.

# NovaForge Studio Pro — v4.1.0

NovaForge is a multi-model AI Software Factory control plane. This release turns the previous baseline into an executable foundation: durable jobs, tenant-scoped projects, hashed API keys, a provider-neutral AI gateway, a worker process, security checks and release gates.

## Architecture

`Client → API v1 → PostgreSQL Job → Worker → AI Provider Gateway → Artifact/Result`

Provider adapters currently cover text/app/bot workloads through:
- OpenAI Responses API
- Anthropic Messages API
- Gemini generateContent API

The provider/model is configuration-driven. Do not hard-code a vendor into business logic.

## API

All machine API endpoints use `x-api-key` or `Authorization: Bearer ...`.

- `POST /api/v1/keys` — bootstrap first key using `ADMIN_BOOTSTRAP_TOKEN`.
- `POST /api/v1/projects` — create a project.
- `GET /api/v1/projects` — list owned projects.
- `POST /api/v1/ai/generate` — enqueue a text/app/bot job.
- `GET /api/v1/jobs/:id` — read a job.
- `POST /api/v1/jobs/:id` — execute one queued job synchronously for development/smoke testing.
- `GET /api/health` — health probe.

## Local

1. Copy `.env.example` to `.env.local` and set real values.
2. Start PostgreSQL: `docker compose up -d postgres`.
3. Install dependencies: `npm install` (or `npm ci` when a lockfile is present).
4. Generate Prisma: `npm run db:generate`.
5. Apply the schema/migrations.
6. Start the app: `npm run dev`.
7. Start a worker: `npm run worker`.

## Production

Use the networked CI runner to install dependencies and execute the complete release gates. Deploy immutable images to Cloud Run. Put `DATABASE_URL`, AI credentials and bootstrap credentials in Secret Manager or equivalent; never commit them.

## Important honesty boundary

The supplied v4.0 archive did not contain the full application described in the earlier Markdown transcript; it contained a production baseline with 27 files. This v4.1 release implements the missing control-plane/AI job foundation without claiming that Google Play, GitHub, Cloud Run or third-party AI accounts have already been connected or published.

Image/video generation remains an explicit adapter boundary. A missing provider is reported as a configuration error; NovaForge never returns a fake media URL.

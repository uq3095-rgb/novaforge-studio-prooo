import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "novaforge-studio-pro",
    version: process.env.APP_VERSION ?? "dev",
    timestamp: new Date().toISOString()
  });
}

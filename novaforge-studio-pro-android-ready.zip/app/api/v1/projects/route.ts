import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { authenticateApiKey, unauthorized } from "@/lib/api/auth";
import { prisma } from "@/lib/prisma";
const schema = z.object({ name: z.string().min(2).max(100), slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(80), repository: z.string().url().optional() });
export async function GET(req: NextRequest) { const key = await authenticateApiKey(req); if (!key) return unauthorized(); return NextResponse.json(await prisma.project.findMany({ where: { ownerId: key.userId }, orderBy: { createdAt: "desc" } })); }
export async function POST(req: NextRequest) { const key = await authenticateApiKey(req); if (!key) return unauthorized(); const parsed = schema.safeParse(await req.json()); if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 }); const project = await prisma.project.create({ data: { ...parsed.data, ownerId: key.userId } }); return NextResponse.json(project, { status: 201 }); }

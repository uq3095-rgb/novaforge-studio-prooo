import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    api: "v1",
    version: process.env.APP_VERSION ?? "dev"
  });
}

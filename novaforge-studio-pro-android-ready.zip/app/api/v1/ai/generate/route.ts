import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { authenticateApiKey, unauthorized } from "@/lib/api/auth";
import { createJob } from "@/lib/jobs/service";

const schema = z.object({ type: z.enum(["text", "app", "bot"]), prompt: z.string().min(3).max(100_000), model: z.string().max(100).optional(), system: z.string().max(20_000).optional(), maxOutputTokens: z.number().int().min(256).max(32_000).optional(), projectId: z.string().optional() });
export async function POST(req: NextRequest) { const key = await authenticateApiKey(req); if (!key) return unauthorized(); const parsed = schema.safeParse(await req.json()); if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 }); const job = await createJob(key.userId, parsed.data, parsed.data.projectId); return NextResponse.json({ id: job.id, status: job.status, poll: `/api/v1/jobs/${job.id}` }, { status: 202 }); }

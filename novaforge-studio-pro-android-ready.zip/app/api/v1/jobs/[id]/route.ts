import { NextRequest, NextResponse } from "next/server";
import { authenticateApiKey, unauthorized } from "@/lib/api/auth";
import { prisma } from "@/lib/prisma";
import { runJob } from "@/lib/jobs/service";
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) { const key = await authenticateApiKey(req); if (!key) return unauthorized(); const { id } = await params; const job = await prisma.job.findFirst({ where: { id, userId: key.userId } }); if (!job) return NextResponse.json({ error: "Job not found" }, { status: 404 }); return NextResponse.json(job); }
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) { const key = await authenticateApiKey(req); if (!key) return unauthorized(); const { id } = await params; const job = await prisma.job.findFirst({ where: { id, userId: key.userId } }); if (!job) return NextResponse.json({ error: "Job not found" }, { status: 404 }); if (job.status !== "QUEUED") return NextResponse.json({ error: "Only queued jobs can be started" }, { status: 409 }); const result = await runJob(id); return NextResponse.json(result); }

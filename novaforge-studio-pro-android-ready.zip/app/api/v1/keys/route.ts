import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createApiKey } from "@/lib/security/api-key";
const schema = z.object({ email: z.string().email(), name: z.string().min(1).max(100) });
export async function POST(req: NextRequest) { const bootstrap = process.env.ADMIN_BOOTSTRAP_TOKEN; if (!bootstrap || req.headers.get("x-admin-bootstrap-token") !== bootstrap) return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); const parsed = schema.safeParse(await req.json()); if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 }); const user = await prisma.user.upsert({ where: { email: parsed.data.email }, update: {}, create: { email: parsed.data.email } }); const generated = createApiKey(); await prisma.apiKey.create({ data: { userId: user.id, name: parsed.data.name, keyHash: generated.keyHash, prefix: generated.prefix } }); return NextResponse.json({ apiKey: generated.key, warning: "Store this key now. It cannot be recovered." }, { status: 201 }); }

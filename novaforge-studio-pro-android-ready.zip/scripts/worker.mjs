import { PrismaClient } from "@prisma/client";
import { generate, generateApp } from "../lib/ai/gateway.ts";
const prisma = new PrismaClient(); const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function tick() { const job = await prisma.job.findFirst({ where: { status: "QUEUED" }, orderBy: { createdAt: "asc" } }); if (!job) return false; const claimed = await prisma.job.updateMany({ where: { id: job.id, status: "QUEUED" }, data: { status: "RUNNING", startedAt: new Date() } }); if (!claimed.count) return true; try { const input = job.input; const result = input.type === "app" ? await generateApp(input.prompt, input.model) : await generate(input); await prisma.job.update({ where: { id: job.id }, data: { status: "SUCCEEDED", output: result, finishedAt: new Date() } }); } catch (error) { await prisma.job.update({ where: { id: job.id }, data: { status: "FAILED", error: error?.message ?? String(error), finishedAt: new Date() } }); } return true; }
console.log("NovaForge worker started");
while (true) { const didWork = await tick(); if (!didWork) await sleep(Number(process.env.WORKER_POLL_MS ?? 1500)); }

import type { GenerateRequest, ProviderName, ProviderResult } from "./types";

const env = (name: string) => process.env[name];

function jsonHeaders(apiKey: string) {
  return { "content-type": "application/json", authorization: `Bearer ${apiKey}` };
}

async function openAI(req: GenerateRequest): Promise<ProviderResult> {
  const apiKey = env("OPENAI_API_KEY");
  if (!apiKey) throw new Error("OPENAI_API_KEY is not configured");
  const model = req.model ?? env("OPENAI_MODEL") ?? "gpt-5.6-luna";
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: jsonHeaders(apiKey),
    body: JSON.stringify({ model, instructions: req.system, input: req.prompt, max_output_tokens: req.maxOutputTokens ?? 4096 }),
  });
  if (!response.ok) throw new Error(`OpenAI ${response.status}: ${await response.text()}`);
  const data = await response.json() as any;
  const text = data.output_text ?? data.output?.flatMap((x: any) => x.content ?? []).map((x: any) => x.text ?? "").join("") ?? "";
  return { provider: "openai", model, text, usage: { inputTokens: data.usage?.input_tokens, outputTokens: data.usage?.output_tokens } };
}

async function anthropic(req: GenerateRequest): Promise<ProviderResult> {
  const apiKey = env("ANTHROPIC_API_KEY");
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY is not configured");
  const model = req.model ?? env("ANTHROPIC_MODEL") ?? "claude-sonnet-4-6";
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model, max_tokens: req.maxOutputTokens ?? 4096, system: req.system, messages: [{ role: "user", content: req.prompt }] }),
  });
  if (!response.ok) throw new Error(`Anthropic ${response.status}: ${await response.text()}`);
  const data = await response.json() as any;
  const text = (data.content ?? []).filter((x: any) => x.type === "text").map((x: any) => x.text).join("\n");
  return { provider: "anthropic", model, text, usage: { inputTokens: data.usage?.input_tokens, outputTokens: data.usage?.output_tokens } };
}

async function gemini(req: GenerateRequest): Promise<ProviderResult> {
  const apiKey = env("GEMINI_API_KEY");
  if (!apiKey) throw new Error("GEMINI_API_KEY is not configured");
  const model = req.model ?? env("GEMINI_MODEL") ?? "gemini-2.5-pro";
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ systemInstruction: req.system ? { parts: [{ text: req.system }] } : undefined, contents: [{ role: "user", parts: [{ text: req.prompt }] }] }),
  });
  if (!response.ok) throw new Error(`Gemini ${response.status}: ${await response.text()}`);
  const data = await response.json() as any;
  const text = data.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? "").join("") ?? "";
  return { provider: "gemini", model, text, usage: { inputTokens: data.usageMetadata?.promptTokenCount, outputTokens: data.usageMetadata?.candidatesTokenCount } };
}

const providers: Record<ProviderName, (req: GenerateRequest) => Promise<ProviderResult>> = { openai: openAI, anthropic, gemini };

export async function generate(req: GenerateRequest): Promise<ProviderResult> {
  const requested = (process.env.AI_PROVIDER as ProviderName | undefined);
  const order: ProviderName[] = requested ? [requested, "openai", "anthropic", "gemini"] : ["openai", "anthropic", "gemini"];
  const seen = new Set<ProviderName>();
  const errors: string[] = [];
  for (const provider of order) {
    if (seen.has(provider)) continue;
    seen.add(provider);
    try { return await providers[provider](req); } catch (error) { errors.push(`${provider}: ${error instanceof Error ? error.message : String(error)}`); }
  }
  throw new Error(`No AI provider succeeded. ${errors.join(" | ")}`);
}

export async function generateApp(prompt: string, model?: string) {
  return generate({ type: "app", prompt: `Create a production-ready software specification and implementation plan for:\n${prompt}\nReturn architecture, files, APIs, data model, tests, security controls and deployment plan.`, model, system: "You are NovaForge Architect/Coder. Never claim code was executed or deployed unless evidence exists." });
}

export type ProviderName = "openai" | "anthropic" | "gemini";
export type GenerationType = "text" | "app" | "bot";

export interface GenerateRequest {
  type: GenerationType;
  prompt: string;
  model?: string;
  system?: string;
  maxOutputTokens?: number;
}

export interface ProviderResult {
  provider: ProviderName;
  model: string;
  text: string;
  usage?: { inputTokens?: number; outputTokens?: number };
}

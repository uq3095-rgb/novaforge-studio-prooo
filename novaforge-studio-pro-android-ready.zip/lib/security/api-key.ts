import { createHash, randomBytes } from "node:crypto";

export function hashApiKey(key: string) {
  return createHash("sha256").update(key).digest("hex");
}

export function createApiKey(prefix = "nf_live") {
  const secret = randomBytes(32).toString("base64url");
  const key = `${prefix}_${secret}`;
  return { key, prefix, keyHash: hashApiKey(key) };
}

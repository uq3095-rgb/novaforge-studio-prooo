import { prisma } from "@/lib/prisma";
import { generate, generateApp } from "@/lib/ai/gateway";
import type { GenerateRequest } from "@/lib/ai/types";

export async function createJob(userId: string, input: GenerateRequest, projectId?: string) {
  return prisma.job.create({ data: { userId, projectId, type: input.type, input } });
}

export async function runJob(jobId: string) {
  const job = await prisma.job.update({ where: { id: jobId }, data: { status: "RUNNING", startedAt: new Date(), error: null } });
  try {
    const input = job.input as unknown as GenerateRequest;
    const result = input.type === "app" ? await generateApp(input.prompt, input.model) : await generate(input);
    return prisma.job.update({ where: { id: jobId }, data: { status: "SUCCEEDED", output: result, finishedAt: new Date() } });
  } catch (error) {
    return prisma.job.update({ where: { id: jobId }, data: { status: "FAILED", error: error instanceof Error ? error.message : String(error), finishedAt: new Date() } });
  }
}

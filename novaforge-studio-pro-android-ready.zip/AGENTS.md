# NovaForge agent operating contract

## Mission
Build and ship software through verifiable stages. Prefer a correct, observable, replaceable system over a fast demo.

## Execution policy
- Work autonomously when the required intent is clear.
- Prefer the technically strongest reversible choice.
- Do not ask for a decision when a safe default exists.
- Do not fabricate provider support, build success, deployment success, credentials, URLs or test evidence.
- If an external dependency is unavailable, implement the adapter/contract and report the exact gate that remains external.

## Architecture
- Control plane: Next.js App Router.
- State: PostgreSQL/Prisma.
- AI: provider-neutral gateway.
- Jobs: durable queue state + isolated worker.
- Generated code: never execute in the web process.
- Secrets: environment/secret manager only.
- APIs: versioned and tenant-scoped.

## Release gates
1. source/release checks
2. dependency installation
3. typecheck
4. unit/integration tests
5. production build
6. dependency/security audit
7. container build
8. deployment smoke tests
9. rollback verification

A release is not "production-ready" until all applicable gates have evidence.

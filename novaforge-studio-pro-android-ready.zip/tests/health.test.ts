import { describe, expect, it } from "vitest";

describe("release baseline", () => {
  it("has a valid application identity", () => {
    expect("novaforge-studio-pro").toBe("novaforge-studio-pro");
  });
});
